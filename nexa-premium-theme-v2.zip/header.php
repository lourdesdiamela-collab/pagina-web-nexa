<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>

    <!-- Premium Noise Texture -->
    <div class="bg-noise"></div>

    <!-- Navigation -->
    <nav class="nav" id="mainNav">
        <div class="container nav-inner">
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nav-logo">
                <svg width="32" height="32" viewBox="0 0 100 100" fill="none">
                    <rect x="20" y="20" width="60" height="60" rx="8" stroke="#12141D" stroke-width="5" />
                    <circle cx="20" cy="20" r="7" fill="#12141D" />
                    <circle cx="80" cy="20" r="7" fill="#12141D" />
                    <circle cx="20" cy="80" r="7" fill="#12141D" />
                    <circle cx="80" cy="80" r="7" fill="#12141D" />
                    <path d="M35 70V30L65 70V30" stroke="#12141D" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                <span class="nav-logo-text">NEXA</span>
            </a>
            
            <div class="nav-links">
                <a href="#servicios" class="nav-link">Servicios</a>
                <a href="#metodologia" class="nav-link">Metodología</a>
                <a href="#faq" class="nav-link">FAQ</a>
                <a href="#contacto" class="nav-cta">Quiero mi auditoría</a>
            </div>

            <button class="mobile-toggle" id="mobileToggle" aria-label="Menu">
                <i data-lucide="menu"></i>
            </button>
        </div>

        <!-- Mobile Menu (Controlled via main.js) -->
        <div class="mobile-menu" id="mobileMenu">
            <a href="#servicios" class="mobile-link">Servicios</a>
            <a href="#metodologia" class="mobile-link">Metodología</a>
            <a href="#faq" class="mobile-link">FAQ</a>
            <a href="#contacto" class="btn btn-primary" style="justify-content:center;">Quiero mi auditoría</a>
        </div>
    </nav>

    <!-- WhatsApp Floating Button -->
    <!-- IMPORTANTE: Reemplazá '5491100000000' con tu número de WhatsApp real (código de país + número, sin el + ni espacios) -->
    <a href="https://wa.me/5491100000000?text=Hola%20Nexa,%20quiero%20agendar%20una%20auditor%C3%ADa" target="_blank" class="whatsapp-float" aria-label="Contact us on WhatsApp">
        <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
        </svg>
    </a>
