<section id="contacto" class="contact">
    <div class="container">
        <div class="contact-card gsap-fade-in-up">
            <div class="contact-grid">
                <div>
                    <h2 class="contact-title">
                        Ordenemos tu <br/><span class="text-gradient-lima">crecimiento.</span>
                    </h2>
                    <p class="contact-desc">
                        Completá el form y agendamos una videollamada de 20 minutos para hacer una auditoría express de tu ecosistema actual.
                    </p>
                </div>
                
                <form class="contact-form" id="nexaContactForm" action="#" onsubmit="event.preventDefault(); alert('¡Gracias por tu interés! Este es un formulario de prueba. Para recibir correos reales, instale el plugin WPForms y reemplace este HTML con su Shortcode.');">
                    <div class="form-group">
                        <label for="brand_name">Nombre de tu marca/agencia</label>
                        <input type="text" id="brand_name" name="brand_name" placeholder="Ej: Clínica Revive" required />
                    </div>
                    <div class="form-group">
                        <label for="email">Email profesional</label>
                        <input type="email" id="email" name="email" placeholder="hola@tumarca.com" required />
                    </div>
                    <!-- Integración sugerida: Reemplazar todo este <form> por el shortcode de WPForms o Contact Form 7 -->
                    <button type="submit" class="btn-submit">Solicitar auditoría gratuita</button>
                </form>
            </div>
        </div>
    </div>
</section>
